<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    use HasFactory;

    protected $table = 'programs';

    const PROGRAM_AKTIF = 1;
    const PROGRAM_TIDAK_AKTIF = 2;

    protected $fillable = [
        'judul',
        'deskripsi',
        'program_yang_berhasil_dijalankan',
        'foto_image',
        'status_program',
        'thumbnail_image'
    ];

    // Menentukan kolom-kolom yang harus di-cast
    protected $casts = [
        'foto_image' => 'array', // Mengonversi kolom foto_image menjadi array
    ];

    public function getStatusProgramAttribute()
    {
        // Akses nilai asli dari kolom status
        return $this->attributes['status_program'] == self::PROGRAM_AKTIF ? 'Aktif' : 'Tidak Aktif';
    }
}
