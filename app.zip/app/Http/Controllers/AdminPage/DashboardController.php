<?php

namespace App\Http\Controllers\AdminPage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Testimoni;
use App\Models\MitraDonatur;
use App\Models\Kontak;
use Illuminate\Support\Facades\Http;

class DashboardController extends Controller
{
    public function dashboard() {
        // Menghitung jumlah Testimoni yang Aktif
        $totalTestimoni = Testimoni::where('statuss_testimoni', Testimoni::TESTIMONI_AKTIF)->count();

        // Mengambil jumlah berita dari API
        $totalBerita = 0; // Default jika API gagal
        try {
            $response = Http::get('https://berbagipendidikan.org/api/berita/counting');
            if ($response->successful() && isset($response['total_berita'])) {
                $totalBerita = $response['total_berita'];
            }
        } catch (\Exception $e) {
            $totalBerita = 'Error fetching data'; // Jika terjadi error saat mengambil API
        }

        // Menghitung jumlah Mitra Donatur
        $totalMitraDonatur = MitraDonatur::count();

        // Menghitung jumlah Kantor Cabang (dari tabel Kontak)
        $totalKantorCabang = Kontak::count();

        return view('AdminPage.dashboard', compact('totalTestimoni', 'totalBerita', 'totalMitraDonatur', 'totalKantorCabang'));
    }
}
