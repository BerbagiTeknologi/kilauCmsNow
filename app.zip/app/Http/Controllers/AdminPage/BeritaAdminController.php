<?php

namespace App\Http\Controllers\AdminPage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BeritaAdminController extends Controller
{
    // Menampilkan halaman berita di admin
    public function index()
    {
        return view('AdminPage.Berita.index'); // Tidak perlu mengirimkan data karena akan di-load via AJAX
    }
}
