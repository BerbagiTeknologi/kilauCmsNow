<?php

namespace App\Http\Controllers\AdminPage;

use App\Models\Program;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class ProgramController extends Controller
{
    public function index()
    {
        $program = Program::all();
        return view('AdminPage.Program.index', compact('program'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'program_yang_berhasil_dijalankan' => 'required|integer|min:0|max:100',
            'foto_image.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', 
            'thumbnail_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Membuat objek program baru
        $timeline = new Program();
        $timeline->judul = $request->judul;
        $timeline->deskripsi = $request->deskripsi;
        $timeline->program_yang_berhasil_dijalankan = $request->program_yang_berhasil_dijalankan;
        $timeline->status_program = Program::PROGRAM_AKTIF; // Status default

        // Menangani upload gambar
        if ($request->hasFile('foto_image')) {
            $images = [];
            foreach ($request->file('foto_image') as $image) {
                // Menyimpan gambar di storage public dan menambah path ke array
                $path = $image->store('program_images', 'public');
                $images[] = $path;
            }
            // Menyimpan array path gambar ke kolom foto_image
            $timeline->foto_image = $images;
        }

        if ($request->hasFile('thumbnail_image')) {
            $path = $request->file('thumbnail_image')->store('program_thumbnail', 'public'); 
            $timeline->thumbnail_image = $path;
        }

        // Menyimpan data program
        $timeline->save();

        // Mengarahkan ke halaman program dengan pesan sukses
        return redirect()->route('program')->with('success', 'Program berhasil ditambahkan.');
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'deskripsi' => 'required|string',
            'program_yang_berhasil_dijalankan' => 'nullable|string|max:500',
            'foto_image.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Validasi gambar
            'thumbnail_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Menemukan data yang akan diperbarui
        $timeline = Program::findOrFail($id);
        $timeline->judul = $request->judul;
        $timeline->deskripsi = $request->deskripsi;
        $timeline->program_yang_berhasil_dijalankan = $request->program_yang_berhasil_dijalankan;

        // Menangani upload gambar baru jika ada
        if ($request->hasFile('foto_image')) {
            $images = [];
            foreach ($request->file('foto_image') as $image) {
                // Menyimpan gambar di storage public dan menambah path ke array
                $path = $image->store('program_images', 'public');
                $images[] = $path;
            }
            // Menyimpan array path gambar ke kolom foto_image
            $timeline->foto_image = $images;
        } else {
            // Jika tidak ada gambar baru, tetap menyimpan gambar lama
            $timeline->foto_image = $timeline->foto_image; 
        }

        if ($request->hasFile('thumbnail_image')) {
            if ($timeline->file && Storage::disk('public')->exists($timeline->file)) {
                Storage::disk('public')->delete($timeline->file);
            }

            $path = $request->file('thumbnail_image')->store('program_thumbnail', 'public'); 
            $timeline->thumbnail_image = $path;
        }


        // Menyimpan data program setelah diperbarui
        $timeline->save();

        // Mengarahkan ke halaman program dengan pesan sukses
        return redirect()->route('program')->with('success', 'Program berhasil diperbarui.');
    }

    public function toggleStatus(Request $request, $id)
    {
        // Validasi status program
        $request->validate([
            'status_program' => 'required|in:1,2', // Validasi status program (Aktif/Tidak Aktif)
        ]);
    
        // Menemukan data program yang sesuai dengan ID
        $program = Program::findOrFail($id);
    
        // Update status program
        $program->status_program = $request->input('status_program');
        $program->save();
    
        // Redirect kembali dengan pesan sukses
        return redirect()->route('program')->with('success', 'Status program berhasil diubah!');
    }
    


    public function destroy($id)
    {
        // Mengambil data program yang akan dihapus
        $timeline = Program::findOrFail($id);

        // Menghapus gambar yang ada jika ada
        if ($timeline->foto_image) {
            foreach ($timeline->foto_image as $image) {
                // Menghapus gambar dari storage jika ada
                if (Storage::disk('public')->exists($image)) {
                    Storage::disk('public')->delete($image);
                }
            }
        }

        // Menghapus data program
        $timeline->delete();

        // Mengarahkan kembali dengan pesan sukses
        return redirect()->route('program')->with('success', 'Program berhasil dihapus.');
    }
}
