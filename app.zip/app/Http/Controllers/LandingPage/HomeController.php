<?php

namespace App\Http\Controllers\LandingPage;

use App\Models\Faq;
use App\Models\Kontak;
use App\Models\HomeKilau;
use App\Models\Testimoni;
use App\Models\TentangKami;
use App\Models\MitraDonatur;
use App\Models\SettingsMenu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\IklanKilau;
use App\Models\IklanKilauList;
use App\Models\Program;
use App\Models\Struktur;
use App\Models\TimlineKilau;
use Illuminate\Support\Facades\Http;

class HomeController extends Controller
{
    public function home()
    {
        $testimoniMenu = SettingsMenu::find(2); 
        $testimonis = null;

        if ($testimoniMenu && $testimoniMenu->status == 'Aktif') {
            $testimonis = Testimoni::where('statuss_testimoni', Testimoni::TESTIMONI_AKTIF)->get();
        }

        $faqMenu = SettingsMenu::find(3); 
        $faqs = null;

        if ($faqMenu && $faqMenu->status == 'Aktif') {
            $faqs = Faq::where('status_faqs', Faq::FAQ_AKTIF)->get();
        }

        $mitraMenu = SettingsMenu::find(4); 
        $mitras = null;

        if ($mitraMenu && $mitraMenu->status == 'Aktif') {
            $mitras = MitraDonatur::where('status_mitra', MitraDonatur::MITRA_AKTIF)->get();
        }

        $tentangMenu = SettingsMenu::find(8); 
        $tentangs = null;

        if ($tentangMenu && $tentangMenu->status == 'Aktif') {
            $tentangs = TentangKami::where('status_tentang_kami', TentangKami::TENTANG_AKTIF)->get(); 
        }

        $programMenu = SettingsMenu::find(13); 
        $programs = null;

        if ($programMenu && $programMenu->status == 'Aktif') {
            $programs = Program::where('status_program', Program::PROGRAM_AKTIF)->get(); 
        }

        $timelineMenu = SettingsMenu::find(14); 
        $timelins = null;

        if ($timelineMenu && $timelineMenu->status == 'Aktif') {
            $timelins = TimlineKilau::where('status_timline', TimlineKilau::TIMELINE_AKTIF) 
                ->orderBy('sequence_timeline', 'asc')
                ->get(); 
        }

        $beritaMenu = SettingsMenu::find(7);
        $beritas = null;

        if ($beritaMenu && $beritaMenu->status == 'Aktif') {
            // Ambil data berita dari API hanya jika status menu "Aktif"
            $response = Http::get('https://berbagipendidikan.org/api/berita');

            if ($response->successful() && isset($response['data'])) {
                $beritas = $response['data']; // Data berita dari API
            }
        }

        $homeKilau = HomeKilau::where('status_home_kilau', HomeKilau::HOME_KILAU_AKTIF)->get();

        $iklanKilau = IklanKilau::where('status_kilau', IklanKilau::IKLAN_KILAU_AKTIF)
                        ->with(['iklanKilauLists' => function($query) {
                            $query->where('status_iklan_kilau_list', IklanKilauList::IKLAN_KILAU_LIST_AKTIF); // hanya mengambil yang aktif
                        }])
                        ->get();


        return view('LandingPageKilau.index', compact('testimonis', 'faqs', 'mitras', 'testimoniMenu', 'faqMenu', 'mitraMenu', 'programMenu', 'programs', 'beritaMenu', 'beritas', 'timelineMenu', 'timelins', 'tentangMenu', 'tentangs', 'homeKilau', 'iklanKilau'));
    }

    public function testimoniCreate(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'pekerjaan' => 'nullable',
            'komentar' => 'required',
            'file' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $testimoni = new Testimoni;
        $testimoni->nama = $request->nama;
        $testimoni->pekerjaan = $request->pekerjaan;
        $testimoni->komentar = $request->komentar;

        if ($request->hasFile('file')) {
            $path = $request->file('file')->store('testimoni', 'public'); 
            $testimoni->file = $path;
        }

        $testimoni->statuss_testimoni = Testimoni::TESTIMONI_TIDAK_AKTIF; // Default Tidak Aktif
        $testimoni->save();

        return redirect()->route('home')->with('success', 'Testimoni created successfully.');
    }
}