<?php

namespace App\Http\Controllers\LandingPage;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;

class BeritaController extends Controller
{
    public function berita() {
        return view('LandingPageKilau.berita');
    }

    public function show($id)
    {
        // Ambil data berita dari API
        $response = Http::get("https://berbagipendidikan.org/api/berita/{$id}");

        if ($response->successful()) {
            $berita = $response->json()['data']; // Ambil data berita dari response API
            return view('LandingPageKilau.berita', compact('berita'));
        } else {
            abort(404); // Jika berita tidak ditemukan, tampilkan error 404
        }
    }

}
