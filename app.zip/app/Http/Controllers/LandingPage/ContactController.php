<?php

namespace App\Http\Controllers\LandingPage;

use App\Models\Kontak;
use App\Models\SettingsMenu;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ContactController extends Controller
{
    public function contact() {
        // Cek apakah menu "Kontak" aktif
        $kontakMenu = SettingsMenu::find(5); 
        $kontaks = []; // Inisialisasi sebagai array kosong

        if ($kontakMenu && $kontakMenu->status == 'Aktif') {
            $kontaks = Kontak::where('status_kontak', Kontak::KONTAK_AKTIF)->get();
        }

        return view('LandingPageKilau.kontak', compact('kontakMenu', 'kontaks'));
    }
}
