<?php

namespace App\Http\Controllers\LandingPage;

use App\Models\Struktur;
use App\Models\SettingsMenu;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Pimpinan;
use App\Models\Sejarah;
use App\Models\VisiMisi;

class ProfileController extends Controller
{
    public function profilPimpinan() {
        $pimpinanMenu = SettingsMenu::find(9); 
        $pimpinans = null;
    
        if ($pimpinanMenu && $pimpinanMenu->status == 'Aktif') {
            $pimpinans = Pimpinan::where('status_pimpinan', Pimpinan::PIMPINAN_AKTIF)->get();
        }
        
        return view('LandingPageKilau.Profile.profilePimpinan', compact('pimpinanMenu', 'pimpinans'));
    }

    public function profilStruktur() {
        $strukturMenu = SettingsMenu::find(9); 
        $strukturs = null;
    
        if ($strukturMenu && $strukturMenu->status == 'Aktif') {
            $strukturs = Struktur::where('status_struktur', Struktur::STRUKTUR_AKTIF)->get();
        }
    
        return view('LandingPageKilau.profile.profilStruktur', compact('strukturMenu', 'strukturs'));
    }

    public function profilSejarah() {
        $sejarahMenu = SettingsMenu::find(10); 
        $sejarahs = null;
    
        if ($sejarahMenu && $sejarahMenu->status == 'Aktif') {
            $sejarahs = Sejarah::where('status_sejarah', Sejarah::SEJARAH_AKTIF)->get();
        }

        return view('LandingPageKilau.profile.profilSejarah', compact('sejarahMenu', 'sejarahs'));
    }

    public function profilVisiMisi() {
        $visimisiMenu = SettingsMenu::find(11);
        $visimisis = null;

        if($visimisiMenu && $visimisiMenu->status == 'Aktif') {
            $visimisis = VisiMisi::where('status_visimisi', VisiMisi::VISI_MISI_AKTIF)->get();
        }

        return view('LandingPageKilau.profile.profilVisiMisi', compact('visimisiMenu', 'visimisis'));
    }
}
