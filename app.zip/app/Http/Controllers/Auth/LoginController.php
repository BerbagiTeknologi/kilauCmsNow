<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;

class LoginController extends Controller
{
    public function login() {
        return view('Auth.login');
    }

    /* public function loginProses(Request $request)
    {
        // Validasi input
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);

        $response = $this->makeApiRequest([
            'email' => $request->email,
            'password' => $request->password,
        ]);

        if ($response->status() == 200) {
            $data = $response->json();

            // Debug response dari API eksternal
            // dd($data);

            if (isset($data['token'])) {
                // Simpan data user ke session
                session([
                    // 'user_id' => $data['berhasil']['id'],
                    'user_name' => $data['berhasil']['nama'],
                    'user_email' => $data['berhasil']['email'],
                    'user_role' => $data['berhasil']['cms'] ?? 'admin',
                    'user_token' => $data['token'],
                ]);

                // Redirect ke dashboard
                return response()->json([
                    'message' => 'Login berhasil!',
                    'redirect_url' => route('dashboardlogin'),
                ]);
            }

            return response()->json([
                'error' => 'Akun Anda tidak memiliki token.',
            ], 400);
        }

        return response()->json([
            'error' => $response->json()['message'] ?? 'Login gagal.',
        ], $response->status());
    } */

     /* private function makeApiRequest(array $data)
    {
        try {
            return Http::post('https://kilauindonesia.org/api/login_sso', $data);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Gagal menghubungi server eksternal.'], 500);
        }
    } */

    public function loginProses(Request $request)
    {
        // Validasi input
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);

        // Kirim data ke API eksternal
        $response = $this->makeApiRequest([
            'email' => $request->email,
            'password' => $request->password,
        ]);

        if ($response->status() == 200) {
            $data = $response->json();

            if (isset($data['token'])) {
                // Simpan data user ke session
                session([
                    'user_name' => $data['berhasil']['nama'],
                    'user_email' => $data['berhasil']['email'],
                    'user_role' => $data['berhasil']['cms'] ?? 'admin',
                    'user_token' => $data['token'],
                    'user_level' => $data['berhasil']['level'],
                ]);

                // Cek jika token ada, langsung redirect ke dashboard
                if (session('user_token')) {
                    return response()->json([
                        'message' => 'Login berhasil!',
                        'redirect_url' => route('dashboard'), // Redirect ke dashboard login
                    ]);
                } else {
                    return response()->json([
                        'error' => 'Gagal menyimpan token ke session.',
                    ], 500);
                }
            }

            return response()->json([
                'error' => 'Akun Anda tidak memiliki token.',
            ], 400);
        }

        return response()->json([
            'error' => $response->json()['message'] ?? 'Login gagal.',
        ], $response->status());
    }

    private function makeApiRequest(array $data)
    {
        try {
            return Http::post('https://kilauindonesia.org/api/login_sso', $data);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Gagal menghubungi server eksternal.'], 500);
        }
    }


    public function logout(Request $request)
    {
        // Hapus semua data dari session
        $request->session()->flush();

        // Redirect ke halaman login dengan pesan sukses
        return redirect('/login')->with('success', 'Logout berhasil!');
    }
    
}